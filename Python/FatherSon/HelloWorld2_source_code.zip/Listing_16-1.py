# Listing_16-1.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# try to make a Pygame window appear

import pygame
pygame.init()
screen = pygame.display.set_mode([640, 480])
