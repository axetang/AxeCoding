# Listing_8-3.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Printing the 8 times table

for looper in [1, 2, 3, 4, 5]:
    print looper, "times 8 =", looper * 8
