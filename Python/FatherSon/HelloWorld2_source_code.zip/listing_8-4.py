# Listing_8-4.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# A loop using range()

for looper in range (1, 5):
    print looper, "times 8 =", looper * 8
