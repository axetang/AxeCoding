# Listing_1-1.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Our first program

print "I love pizza!"
print "pizza " * 20
print "yum " * 40
print "I'm full."
