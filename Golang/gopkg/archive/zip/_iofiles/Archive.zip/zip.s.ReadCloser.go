/************************************************************************************
 **Author:  Axe Tang; Email: axetang@163.com
 **Package: zip
 **Element: zip.ReadCloser
 **Type: struct
 ------------------------------------------------------------------------------------
 **Definition:
 type ReadCloser struct {
     Reader
     // contains filtered or unexported fields
 }
 func (rc *ReadCloser) Close() error
 ------------------------------------------------------------------------------------
 **Description:
 Close closes the Zip file, rendering it unusable for I/O.
 ------------------------------------------------------------------------------------
 **要点总结:
*************************************************************************************/
package main

func main() {
}
